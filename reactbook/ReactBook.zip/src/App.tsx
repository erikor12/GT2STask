import './App.css'
import Publicacion from './components/publicacion'

function App() {

  return (
    <>
      <Publicacion />
    </>
  )
}

export default App
